Fotografias de jogadores
=======================

As pastas estao organizadas por pais e clube, de acordo com os caminhos usados
no jogo: jogadores/<pais>/<clube>/.

Para adicionar fotografias, abre Logotipos > Importar pack de faces e seleciona
a pasta jogadores. Usa imagens PNG, JPEG ou WebP. Nomeia cada ficheiro com o
nome completo do jogador; para nomes repetidos, inclui o ID do clube ou o
codigo da liga na subpasta. A aplicacao associa e guarda as imagens no
navegador atual.
