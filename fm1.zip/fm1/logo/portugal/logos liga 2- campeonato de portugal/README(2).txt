FootyLogos — Liga 2 (Portugal)
Season / edition: 2026-27
Format: SVG
Included: 15 logo files
Current collection: 15 available logos
Published participant information: 15 clubs

Each image uses the current stored primary crest. Historical and monochrome variants are excluded, except in a collection specifically dedicated to competition editions.
Club, competition and federation marks belong to their respective owners.
https://www.footylogos.com

Using these files? Credit FootyLogos.com (https://www.footylogos.com/) as the source. A link back is appreciated.
