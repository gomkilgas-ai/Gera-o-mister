FootyLogos — Ligue 1
Season / edition: 2026-27
Format: SVG
Included: 18 logo files
Current collection: 18 available logos
Published participant information: 18 clubs

Each image uses the current stored primary crest. Historical and monochrome variants are excluded, except in a collection specifically dedicated to competition editions.
Club, competition and federation marks belong to their respective owners.
https://www.footylogos.com

Using these files? Credit FootyLogos.com (https://www.footylogos.com/) as the source. A link back is appreciated.
