Club emblem assets

The game loads local SVG files from a country subfolder, for example
"portugal/academico-de-viseu.svg". Filenames use the club name in lowercase,
with accents removed and spaces replaced by hyphens.

Most files are original illustrative emblems using each club's listed colours
and initials; they are not official club logos. Verified real emblems are
included only when a reusable source is available. See "SOURCES.txt" for
exact provenance and license details.

The Benfica, FC Porto, SC Braga, and Vitória SC PNGs are copied from the
locally supplied FMPT-Logopack-V2 pack and matched by visual identity. Their
reuse licenses have not been independently verified; the marks remain the
property of their respective clubs.

Clubs in the Viseu district divisions without a confidently matched pack
image use original illustrative SVGs so their badges do not appear broken.

Keep this folder beside the game HTML file. Real club marks remain trademarks
of their respective owners.
